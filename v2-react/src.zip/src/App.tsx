import AnimationsPage from './pages/AnimationsPage';
// import TestPage from './pages/TestPage';
// import DebugPage from './pages/DebugPage';

/**
 * Main application component - renders the full AnimationsPage
 */
function App() {
  return <AnimationsPage />;
}

export default App;
